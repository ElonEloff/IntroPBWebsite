/* ==========================================================================
   Astronaut cursor
   Replaces the normal mouse pointer with an astronaut that has 3 looks:
     idle    - the mouse is still
     moving  - the mouse is moving (jetpack on, leans into the movement)
     hover   - the mouse is over something clickable (reaches out and points)

   Edit the CONFIG block below to change images, size, or "hot spots".
   ========================================================================== */
(() => {
  'use strict';

  // Touch screens have no mouse pointer, so leave them alone.
  if (window.matchMedia('(hover: none), (pointer: coarse)').matches) return;

  /* ---- CONFIG ---------------------------------------------------------- */
  const CONFIG = {
    size: 72,          // cursor width/height in pixels
    idleDelay: 110,    // ms without movement before switching back to "idle"
    maxTilt: 22,       // degrees the astronaut leans while moving

    // What counts as "clickable". Add your own selectors or use data-clickable.
    clickable: 'a, button, [role="button"], input, select, textarea, label, summary, [data-clickable]',

    // "hotspot" is the spot inside the 100x100 image that actually clicks
    // (the astronaut's glove / fingertip). Values are [x, y] in image units.
    states: {
      idle:   { file: 'cursor-idle.png',   hotspot: [22, 36] },
      moving: { file: 'cursor-moving.png', hotspot: [22, 36] },
      hover:  { file: 'cursor-hover.png',  hotspot: [14, 21] },
    },
  };
  /* ---------------------------------------------------------------------- */

  // Find the /images folder relative to this script, so it works on every page.
  const imagesBase = new URL('../images/', document.currentScript.src);
  const scale = CONFIG.size / 100;

  // Preload every state so there is no flicker on the first swap.
  for (const s of Object.values(CONFIG.states)) {
    s.url = new URL(s.file, imagesBase).href;
    new Image().src = s.url;
  }

  // Build the cursor element.
  const cursor = document.createElement('div');
  cursor.className = 'astro-cursor';
  cursor.setAttribute('aria-hidden', 'true');
  const img = document.createElement('img');
  img.className = 'astro-cursor__img';
  img.alt = '';
  img.draggable = false;
  cursor.appendChild(img);
  cursor.style.setProperty('--cursor-size', CONFIG.size + 'px');
  document.body.appendChild(cursor);

  let state = null;
  let overClickable = false;
  let idleTimer = null;
  let tiltTarget = 0;
  let tiltNow = 0;

  function setState(next) {
    if (next === state) return;
    state = next;
    const s = CONFIG.states[next];
    img.src = s.url;
    cursor.dataset.state = next;
    cursor.style.setProperty('--hx', s.hotspot[0] * scale + 'px');
    cursor.style.setProperty('--hy', s.hotspot[1] * scale + 'px');
  }

  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');

  // Ease the lean toward its target every frame.
  function animate() {
    tiltTarget *= 0.88;
    tiltNow += (tiltTarget - tiltNow) * 0.2;
    const angle = state === 'moving' && !reducedMotion.matches ? tiltNow : 0;
    img.style.transform = angle ? `rotate(${angle.toFixed(2)}deg)` : '';
    requestAnimationFrame(animate);
  }

  let lastX = 0;

  // Pointer events (not mouse events) so the cursor keeps tracking while the
  // spaceman is being dragged.
  document.addEventListener('pointermove', (e) => {
    if (e.pointerType && e.pointerType !== 'mouse' && e.pointerType !== 'pen') return;
    cursor.style.transform = `translate3d(${e.clientX}px, ${e.clientY}px, 0)`;
    cursor.classList.add('is-visible');

    overClickable = !!(e.target.closest && e.target.closest(CONFIG.clickable));
    const dx = e.clientX - lastX;
    lastX = e.clientX;

    if (overClickable) {
      setState('hover');
      clearTimeout(idleTimer);
      return;
    }

    setState('moving');
    tiltTarget = Math.max(-CONFIG.maxTilt, Math.min(CONFIG.maxTilt, dx * 1.4));
    clearTimeout(idleTimer);
    idleTimer = setTimeout(() => setState(overClickable ? 'hover' : 'idle'), CONFIG.idleDelay);
  });

  document.addEventListener('pointerdown', () => cursor.classList.add('is-down'));
  document.addEventListener('pointerup', () => cursor.classList.remove('is-down'));
  document.addEventListener('pointercancel', () => cursor.classList.remove('is-down'));
  document.documentElement.addEventListener('mouseleave', () => cursor.classList.remove('is-visible'));
  document.documentElement.addEventListener('mouseenter', () => cursor.classList.add('is-visible'));

  setState('idle');
  document.documentElement.classList.add('has-custom-cursor');
  animate();
})();
