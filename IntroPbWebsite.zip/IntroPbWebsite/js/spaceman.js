/* ==========================================================================
   Throwable spaceman
   A little astronaut stands at the bottom of the screen. Grab him with the
   mouse (or a finger), carry him around, and let go to throw him. He bounces
   off the floor and walls until he settles.

   He uses three images (see CONFIG.images):
     stand - standing still
     drag  - being held up by the hand
     fly   - let go and moving through the air

   Every setting you might want to tweak is in the CONFIG block below.
   To remove him from a page, delete that page's <script src="js/spaceman.js">.
   ========================================================================== */
(() => {
  'use strict';

  /* ---- CONFIG ---------------------------------------------------------- */
  const CONFIG = {
    images: {
      stand: 'spaceman-stand.png',
      drag:  'spaceman-drag.png',
      fly:   'spaceman-fly.png',
    },
    width: 120,            // on-screen width in px (height follows the image ratio)
    imageRatio: 260 / 200, // image height / image width (all 3 images use 200 x 260)
    startX: 0.82,          // where he starts: 0 = far left, 1 = far right

    // The spot on the "drag" image that sticks to the mouse (his raised glove),
    // measured in the image's own 200 x 260 units.
    handle: { x: 134, y: 20 },

    gravity: 0,            // pixels per second squared (bigger = falls faster)
    floorBounce: 0.55,     // 0 = thud, 1 = perfect bounce
    wallBounce: 0.6,
    floorFriction: 3.2,    // how quickly he slides to a stop on the floor
    airDrag: 0.08,         // slows him a little in the air
    throwPower: 1.0,       // 1 = the throw matches your mouse speed
    maxSpeed: 2500,        // top speed in px per second
    standSpeed: 100,       // below this floor speed he shows the standing image

    bounceSound: 'bounce.mp3', // file inside the /sounds folder
    bounceVolume: 0.6,         // 0 = silent, 1 = full volume
  };
  /* ---------------------------------------------------------------------- */

  const W = CONFIG.width;
  const H = Math.round(W * CONFIG.imageRatio);
  const S = W / 200; // image units -> pixels

  // Hit box (a little smaller than the image so rotating limbs can poke past walls).
  const HX = W * 0.40;
  const HY = H * 0.46; // feet sit ~4% above the bottom edge of the image

  // Where the handle is, relative to the image centre, in pixels.
  const HAND = { x: (CONFIG.handle.x - 100) * S, y: (CONFIG.handle.y - 130) * S };

  const imagesBase = new URL('../images/', document.currentScript.src);
  const urls = {};
  for (const [name, file] of Object.entries(CONFIG.images)) {
    urls[name] = new URL(file, imagesBase).href;
    new Image().src = urls[name]; // preload
  }

  // ---- bounce sound ------------------------------------------------------
  // Must be set up here, while the script is first loading, because
  // document.currentScript is empty once loading has finished.
  const bounceAudio = new Audio(new URL('../sounds/' + CONFIG.bounceSound, document.currentScript.src).href);
  bounceAudio.preload = 'auto';

  let lastBounce = 0;
  function playBounce(impact) {                 // impact = speed (px/s) when he hits
    const now = performance.now();
    if (impact < 250 || now - lastBounce < 80) return;   // skip tiny bumps and rapid repeats
    lastBounce = now;
    const s = bounceAudio.cloneNode();          // a copy, so quick bounces can overlap
    s.volume = Math.min(1, impact / 1500) * CONFIG.bounceVolume;  // harder hit = louder
    s.play().catch(() => {});
  }

  // Build the element.
  const el = document.createElement('img');
  el.className = 'spaceman';
  el.alt = '';
  el.draggable = false;
  el.width = W;
  el.height = H;
  el.setAttribute('data-clickable', ''); // makes the astronaut cursor reach out
  el.src = urls.stand;
  document.body.appendChild(el);

    // "Throw me!" label, shown only while he's standing still.
  const label = document.createElement('div');
  label.className = 'spaceman-label';
  label.textContent = 'Throw me!';
  label.setAttribute('aria-hidden', 'true'); // decorative; his alt/role can carry the real info
  document.body.appendChild(label);

  // ---- state -------------------------------------------------------------
  const view = () => ({ w: document.documentElement.clientWidth, h: document.documentElement.clientHeight });

  let mode = 'rest';        // 'rest' | 'drag' | 'fly'
  let look = 'stand';       // which image is showing
  let x = 0, y = 0;         // centre of the image
  let vx = 0, vy = 0;       // velocity of the centre (px/s)
  let angle = 0, angVel = 0;// degrees, degrees/s

  // dragging
  let pointerId = null;
  let pointerX = 0, pointerY = 0;
  let handX = 0, handY = 0;     // smoothed hand position (follows the pointer)
  let handVX = 0, handVY = 0;   // smoothed hand velocity, used for throwing

  const rad = (d) => (d * Math.PI) / 180;
  const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
  // Rotate a vector by "deg" (clockwise on screen, same as CSS rotate()).
  const rot = (px, py, deg) => {
    const c = Math.cos(rad(deg)), s = Math.sin(rad(deg));
    return [px * c - py * s, px * s + py * c];
  };

  function setLook(next) {
    if (next === look) return;
    look = next;
    el.src = urls[next];
  }

    function place() {
    el.style.transform = `translate(${(x - W / 2).toFixed(1)}px, ${(y - H / 2).toFixed(1)}px) rotate(${angle.toFixed(2)}deg)`;
    label.style.transform = `translate(${(x - label.offsetWidth / 2).toFixed(1)}px, ${(y - H / 2 - 34).toFixed(1)}px)`;
    label.classList.toggle('is-visible', mode === 'rest');
  }

  function floorY() { return view().h - HY; }

  // Start standing on the floor.
  x = clamp(view().w * CONFIG.startX, HX, view().w - HX);
  y = floorY();
  place();

  // ---- grabbing ----------------------------------------------------------
  el.addEventListener('pointerdown', (e) => {
    if (e.button !== undefined && e.button !== 0) return;
    el.setPointerCapture(e.pointerId);
    pointerId = e.pointerId;
    pointerX = e.clientX;
    pointerY = e.clientY;

    // Normalise the angle so the swing spring pulls the short way round.
    angle = ((angle + 180) % 360 + 360) % 360 - 180;

    // Where his handle is right now; it will glide up to the pointer.
    const [hx, hy] = rot(HAND.x, HAND.y, angle);
    handX = x + hx;
    handY = y + hy;
    handVX = handVY = 0;

    mode = 'drag';
    setLook('drag');
    el.classList.add('is-dragging');
  });

  el.addEventListener('pointermove', (e) => {
    if (e.pointerId !== pointerId) return;
    pointerX = e.clientX;
    pointerY = e.clientY;
  });

  function release(e) {
    if (mode !== 'drag' || (e && e.pointerId !== pointerId)) return;
    pointerId = null;
    el.classList.remove('is-dragging');

    // Velocity of his centre = velocity of the hand + the swing around the hand.
    const [ox, oy] = rot(HAND.x, HAND.y, angle);            // hand offset from centre
    const w = rad(angVel);
    vx = (handVX + w * oy) * CONFIG.throwPower;             // v = vHand - w x (r), r = -offset
    vy = (handVY - w * ox) * CONFIG.throwPower;
    const speed = Math.hypot(vx, vy);
    if (speed > CONFIG.maxSpeed) { vx *= CONFIG.maxSpeed / speed; vy *= CONFIG.maxSpeed / speed; }

    angVel = clamp(angVel + vx * 0.10, -900, 900);
    mode = 'fly';
    setLook('fly');
  }
  el.addEventListener('pointerup', release);
  el.addEventListener('pointercancel', release);
  el.addEventListener('lostpointercapture', release);
  el.addEventListener('click', (e) => e.preventDefault());

  // ---- the physics loop --------------------------------------------------
  let last = performance.now();

  function frame(now) {
    const dt = Math.min((now - last) / 1000, 1 / 30);
    last = now;
    if (dt > 0) step(dt);
    requestAnimationFrame(frame);
  }

  function step(dt) {
    const v = view();

    if (mode === 'drag') {
      // Hand chases the pointer.
      const px = clamp(pointerX, 0, v.w), py = clamp(pointerY, 0, v.h);
      const k = 1 - Math.exp(-30 * dt);
      const nx = handX + (px - handX) * k;
      const ny = handY + (py - handY) * k;
      const a = 1 - Math.exp(-dt / 0.05);
      handVX += ((nx - handX) / dt - handVX) * a;
      handVY += ((ny - handY) / dt - handVY) * a;
      handX = nx;
      handY = ny;

      // He trails behind the hand: leans against the direction of travel,
      // with a springy swing.
      const target = clamp(handVX * 0.015, -40, 40);
      angVel += (-90 * (angle - target) - 13 * angVel) * dt;
      angle += angVel * dt;

      // Keep the handle glued to the hand while the body rotates around it.
      const [ox, oy] = rot(HAND.x, HAND.y, angle);
      x = handX - ox;
      y = handY - oy;
      place();
      return;
    }

    if (mode === 'rest') {
      // Follow the floor if the window is resized.
      x = clamp(x, HX, v.w - HX);
      y = v.h - HY;
      place();
      return;
    }

    // ---- flying / sliding ----
    vy += CONFIG.gravity * dt;
    const drag = Math.exp(-CONFIG.airDrag * dt);
    vx *= drag;
    vy *= drag;

    x += vx * dt;
    y += vy * dt;
    angle += angVel * dt;

    // Walls and ceiling (playBounce is called before the speed changes)
    if (x < HX)       { playBounce(Math.abs(vx)); x = HX;       vx = Math.abs(vx) * CONFIG.wallBounce;  angVel *= 0.8; }
    if (x > v.w - HX) { playBounce(Math.abs(vx)); x = v.w - HX; vx = -Math.abs(vx) * CONFIG.wallBounce; angVel *= 0.8; }
    if (y < HY)       { playBounce(Math.abs(vy)); y = HY;       vy = Math.abs(vy) * CONFIG.wallBounce;  angVel *= 0.8; }

    // Floor
    const floor = v.h - HY;
    let grounded = false;
    if (y >= floor) {
      y = floor;
      if (vy > 140) {
        playBounce(vy);
        vy = -vy * CONFIG.floorBounce;
        angVel *= 0.6;
      } else {
        vy = 0;
        grounded = true;
      }
    }

    if (grounded) {
      vx *= Math.exp(-CONFIG.floorFriction * dt);
      angVel = 0;
      // Ease back upright (nearest whole turn).
      const upright = Math.round(angle / 360) * 360;
      angle += (upright - angle) * (1 - Math.exp(-12 * dt));

      if (Math.abs(vx) < 12 && Math.abs(angle - upright) < 1) {
        vx = 0;
        angle = 0;
        mode = 'rest';
        setLook('stand');
        place();
        return;
      }
      setLook(Math.abs(vx) < CONFIG.standSpeed ? 'stand' : 'fly');
    } else {
      setLook('fly');
    }

    place();
  }

  window.addEventListener('resize', () => {
    const v = view();
    x = clamp(x, HX, v.w - HX);
    if (mode === 'rest') y = v.h - HY;
  });

  requestAnimationFrame((t) => { last = t; requestAnimationFrame(frame); });
})();