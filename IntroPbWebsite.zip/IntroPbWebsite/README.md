# Low Orbit

A five-page space website. Plain HTML, one CSS file, and one small script for the astronaut cursor. No build step.

## Open it

- Double-click `index.html`, or
- In VS Code, install the **Live Server** extension, right-click `index.html`, and choose **Open with Live Server**.

## Folder map

```
low-orbit/
├── index.html        Home screen (background image + 4 buttons)
├── about.html        ┐
├── missions.html     │ Inner pages: identical layout,
├── gallery.html      │ only the heading and text differ
├── contact.html      ┘
├── css/
│   └── style.css     ALL of the CSS (colours and fonts are at the top)
├── js/
│   ├── cursor.js     Astronaut cursor logic (edit CONFIG at the top)
│   └── spaceman.js   Throwable spaceman physics (edit CONFIG at the top)
└── images/
    ├── background.jpg      Home screen background (generated)
    ├── cursor-idle.svg     Mouse is still
    ├── cursor-moving.svg   Mouse is moving
    ├── cursor-hover.svg    Mouse is over something clickable
    ├── spaceman-stand.svg  Throwable spaceman: standing still
    ├── spaceman-drag.svg   Throwable spaceman: being held
    └── spaceman-fly.svg    Throwable spaceman: thrown / moving
```

## Common edits

- **Change colours or fonts:** edit the `:root` block at the top of `css/style.css`.
- **Change the home background:** replace `images/background.jpg` (keep the name) or change the `url(...)` in the `.hero` rule.
- **Change the page text:** edit the `<h1>`, `.page__lede`, and the three `.column` sections in each inner page.
- **Add a page:** copy `about.html`, rename it, change the text, then add a link to it in the nav of every page and a button in `index.html`.
- **Make the cursor bigger or smaller:** change `size` in `js/cursor.js`.
- **Make something count as "clickable":** it already works for links, buttons, and form fields. For anything else, add `data-clickable` to the element.
- **Swap the astronaut:** replace the three SVGs in `images/` (100 x 100 canvas). If the glove or fingertip moves, update the matching `hotspot` in `js/cursor.js`.

- **Tune the spaceman:** in `js/spaceman.js`, change `gravity`, `floorBounce`, `throwPower`, or `width`. To swap his art, replace the three `spaceman-*.svg` files (200 x 260 canvas) and set `handle` to where his raised glove is in the drag image.
- **Remove the spaceman from a page:** delete `<script src="js/spaceman.js" defer></script>` from that page.

## Notes

- The cursor is turned off automatically on touch screens.
- Fonts (Unbounded, DM Sans) load from Google Fonts. Offline, the page falls back to system fonts.

## Working on it with Claude Code

Open a terminal in this folder (`claude` in VS Code's terminal) and describe the change, for example: "add a fifth button to the home screen for a Blog page and create blog.html to match the other pages."
